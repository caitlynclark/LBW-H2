.. _WindSource:


Wind Plant
================================

Wind Generation class based on PySAM's Windpower module

.. autoclass:: hybrid.wind_source.WindPlant
    :members:
