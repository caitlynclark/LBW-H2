.. _Grid:


Grid
================================

Class with basic grid functions such as interconnection and curtailment limits based on PySAM's Grid module

.. autoclass:: hybrid.grid.Grid
    :members:
