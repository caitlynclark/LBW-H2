.. _PowerSource:


PowerSource: Abstract Class
================================

Base class for energy generators

.. autoclass:: hybrid.power_source.PowerSource
    :members:
