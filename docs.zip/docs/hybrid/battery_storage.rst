.. _BatteryStorage:


Battery Storage
================================

Battery Storage class based on PySAM's BatteryStateful Model


.. autoclass:: hybrid.battery.Battery
    :members:
